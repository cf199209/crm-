#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @TIME     : 2018/11/21 9:32 PM
# @Author   : Edison-Chen
# @File     : rbac.py
#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @TIME     : 2018/11/21 8:54 PM
# @Author   : Edison-Chen
# @File     : xxx.py
from django.utils.deprecation import MiddlewareMixin
from django.shortcuts import HttpResponse
import re
from django.conf import settings


class RbacPermission(MiddlewareMixin):
    """
    当用户请求进入时进行
    用户权限信息校验
    """
    def process_request(self, request):
        """
        1、获取当前用户请求的url
        2、获取当前用户在session中保存的权限列表
        3、权限信息的匹配
        """
        # 白名单(在setting中配置)

        # 当前请求的url
        current_url = request.path_info
        for valid_url in settings.VALID_URL_LIST:
            # 判断白名单中的url是否跟当前url一样
            if re.match(valid_url, current_url):
                return None  # return None 中间件不拦截


        # 获取session中保存的权限列表
        permission_list = request.session.get(settings.PERMISSION_SESSION_KEY)
        # menu_list = request.session.get(settings.MENU_SESSION_KEY)
        # print(menu_list)
        if not permission_list:
            return HttpResponse('未获取到用户权限信息，请登录！')

        flag = False
        for url in permission_list:
            reg = '^%s$' % url
            if re.match(reg, current_url):
                flag = True
                break

        if not flag:
            return HttpResponse('没有权限访问')


