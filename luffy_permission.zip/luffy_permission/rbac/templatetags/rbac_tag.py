#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @TIME     : 2018/11/22 10:22 AM
# @Author   : Edison-Chen
# @File     : rbac.py
from django.template import Library
from django.conf import settings

register = Library()


@register.inclusion_tag('rbac/static_menu.html')
def static_menu(request):
    """
    创建一级菜单
    :return:
    """
    menu_list = request.session[settings.MENU_SESSION_KEY]
    return {"menu_list":menu_list}
